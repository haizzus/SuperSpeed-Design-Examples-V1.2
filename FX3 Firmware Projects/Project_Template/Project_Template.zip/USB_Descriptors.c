/*
 * USB_Descriptors.c	This file contains the USB enumeration descriptors for the application and a routine that sets them
 *
 */

#include "Application.h"

